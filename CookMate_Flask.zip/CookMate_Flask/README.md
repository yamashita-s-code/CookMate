# CookMate（AIレシピ・在庫管理）

Flaskで作成した、AIレシピ提案と在庫管理の担当部分です。PC・スマートフォンの両方に対応しています。

## 主な機能

- 食材の登録・更新・削除
- 数量・単位・賞味期限の管理
- スマートフォンでの写真撮影・画像登録
- 期限切れ・期限間近の表示
- 在庫食材を選んだレシピ提案
- アレルギーや希望条件の入力
- スマートフォン対応の緑系デザイン
- 入力確認、削除確認、画像プレビュー

## Windowsでの起動方法

PowerShellでこのフォルダーを開き、順番に実行してください。

```powershell
py -m venv venv
venv\Scripts\activate
python -m pip install -r requirements.txt
python app.py
```

ブラウザで `http://127.0.0.1:5000` を開きます。Postmanは必要ありません。

## AIについて

APIキーを設定しなくても、デモ用のレシピ提案が動きます。本物のAI提案を使う場合は、環境変数 `OPENAI_API_KEY` を設定してください。

PowerShellの例：

```powershell
$env:OPENAI_API_KEY="自分のAPIキー"
$env:OPENAI_MODEL="使用するモデル名"
python app.py
```

API通信に失敗した場合は、自動的にデモ提案へ切り替わります。

## ファイル構成

```text
CookMate_Flask/
├─ app.py                 Flaskの画面・イベント処理
├─ database.py            SQLiteの初期化・接続
├─ recipe_service.py      AI／デモレシピ提案
├─ requirements.txt       必要ライブラリ
├─ templates/             HTML画面
├─ static/css/            デザイン
├─ static/js/             補助的なJavaScript
├─ static/uploads/        登録画像
└─ tests/                 動作テスト
```

## 注意

- 初回起動時に `cookmate.db` が自動作成されます。
- 画像は5MB以下のPNG・JPEG・WebPを使用してください。
- 公開時は `SECRET_KEY` を必ず変更してください。
