import json
import os
import urllib.error
import urllib.request


def generate_recipe(items, restrictions, servings):
    ingredient_names = [item["name"] for item in items]
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if api_key:
        try:
            return _generate_with_openai(ingredient_names, restrictions, servings, api_key)
        except (urllib.error.URLError, TimeoutError, KeyError, ValueError, json.JSONDecodeError):
            pass
    return _generate_locally(ingredient_names, restrictions, servings)


def _generate_with_openai(ingredients, restrictions, servings, api_key):
    model = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
    instruction = (
        "あなたは家庭料理のアシスタントです。"
        "指定食材を優先し、料理名、材料、手順、ポイントを日本語で提案してください。"
        "必ずJSONのみを返してください。キーはtitle, ingredients, steps, tipです。"
        "ingredientsとstepsは文字列の配列です。"
    )
    prompt = (
        f"食材: {', '.join(ingredients)}\n"
        f"人数: {servings}人分\n"
        f"要望・アレルギー: {restrictions or 'なし'}"
    )
    body = json.dumps(
        {
            "model": model,
            "input": [
                {"role": "system", "content": instruction},
                {"role": "user", "content": prompt},
            ],
        }
    ).encode("utf-8")
    req = urllib.request.Request(
        "https://api.openai.com/v1/responses",
        data=body,
        method="POST",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
    )
    with urllib.request.urlopen(req, timeout=30) as response:
        payload = json.loads(response.read().decode("utf-8"))
    output_text = payload["output"][0]["content"][0]["text"]
    return json.loads(output_text)


def _generate_locally(ingredients, restrictions, servings):
    main = ingredients[0]
    others = ingredients[1:4]
    title = f"{main}の彩り炒め"
    ingredient_lines = [f"{name}：適量" for name in ingredients]
    ingredient_lines += [
        f"油：小さじ{max(1, servings)}",
        "塩・こしょう：少々",
        "しょうゆ：小さじ1～2",
    ]
    steps = [
        f"{', '.join(ingredients)}を食べやすい大きさに切ります。",
        "フライパンに油を入れ、中火で食材を順番に炒めます。",
        "全体に火が通ったら塩・こしょう、しょうゆで味を調えます。",
        "器に盛り付け、温かいうちに完成です。",
    ]
    if others:
        tip = f"{main}を先に炒め、{', '.join(others)}を後から加えると食感が残ります。"
    else:
        tip = "焦げないように火加減を調整してください。"
    if restrictions:
        tip += f" 「{restrictions}」に該当する調味料・食材は使用前に必ず確認してください。"
    return {
        "title": title,
        "ingredients": ingredient_lines,
        "steps": steps,
        "tip": tip,
        "mode": "デモ提案",
    }
