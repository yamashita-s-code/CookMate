document.addEventListener("DOMContentLoaded", () => {
  const menuButton = document.querySelector(".menu-button");
  const nav = document.querySelector(".main-nav");
  if (menuButton && nav) {
    menuButton.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("open");
      menuButton.setAttribute("aria-expanded", String(isOpen));
    });
  }

  document.querySelectorAll(".image-input").forEach((input) => {
    input.addEventListener("change", () => {
      const preview = input.closest("form").querySelector(".image-preview");
      const file = input.files && input.files[0];
      if (!preview || !file) return;
      preview.src = URL.createObjectURL(file);
      preview.hidden = false;
    });
  });

  document.querySelectorAll(".delete-form").forEach((form) => {
    form.addEventListener("submit", (event) => {
      if (!window.confirm(form.dataset.confirm || "削除しますか？")) {
        event.preventDefault();
      }
    });
  });

  const generateForm = document.querySelector(".generate-form");
  if (generateForm) {
    generateForm.addEventListener("submit", (event) => {
      const checked = generateForm.querySelectorAll("input[name='item_ids']:checked");
      if (checked.length === 0) {
        event.preventDefault();
        window.alert("使用する食材を1つ以上選んでください。");
        return;
      }
      const button = generateForm.querySelector(".generate-button");
      button.disabled = true;
      button.querySelector(".button-label").hidden = true;
      button.querySelector(".loading-label").hidden = false;
    });
  }
});
