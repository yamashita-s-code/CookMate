import tempfile
import unittest
from pathlib import Path

from app import create_app


class CookMateTestCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        database = str(Path(self.tmp.name) / "test.db")
        self.app = create_app(
            {"TESTING": True, "DATABASE": database, "SECRET_KEY": "test-key"}
        )
        self.client = self.app.test_client()

    def tearDown(self):
        self.tmp.cleanup()

    def _token(self):
        self.client.get("/")
        with self.client.session_transaction() as session:
            return session["csrf_token"]

    def test_home_opens(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("CookMate".encode(), response.data)

    def test_inventory_add_and_recipe(self):
        token = self._token()
        response = self.client.post(
            "/inventory/add",
            data={
                "csrf_token": token,
                "name": "キャベツ",
                "quantity": "1",
                "unit": "個",
                "expiry_date": "2030-01-01",
            },
            follow_redirects=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn("キャベツ".encode("utf-8"), response.data)

        response = self.client.post(
            "/recipes",
            data={"csrf_token": token, "item_ids": "1", "servings": "2"},
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn("キャベツの彩り炒め".encode("utf-8"), response.data)


if __name__ == "__main__":
    unittest.main()
