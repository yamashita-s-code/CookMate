import os
import secrets
from datetime import date
from pathlib import Path

from flask import (
    Flask,
    abort,
    flash,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.utils import secure_filename

from database import close_db, get_db, init_db
from recipe_service import generate_recipe


BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "static" / "uploads"
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.from_mapping(
        SECRET_KEY=os.getenv("SECRET_KEY", "dev-change-this-key"),
        DATABASE=str(BASE_DIR / "cookmate.db"),
        UPLOAD_FOLDER=str(UPLOAD_DIR),
        MAX_CONTENT_LENGTH=5 * 1024 * 1024,
    )
    if test_config:
        app.config.update(test_config)

    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    app.teardown_appcontext(close_db)

    with app.app_context():
        init_db()

    @app.before_request
    def prepare_csrf_token():
        session.setdefault("csrf_token", secrets.token_hex(16))
        if request.method == "POST":
            token = request.form.get("csrf_token", "")
            if not secrets.compare_digest(token, session["csrf_token"]):
                abort(400, "不正なリクエストです。画面を再読み込みしてください。")

    @app.context_processor
    def inject_common_values():
        return {"today": date.today().isoformat(), "csrf_token": session.get("csrf_token")}

    @app.get("/")
    def home():
        db = get_db()
        stock_count = db.execute("SELECT COUNT(*) FROM inventory_items").fetchone()[0]
        expiring_count = db.execute(
            """
            SELECT COUNT(*) FROM inventory_items
            WHERE expiry_date IS NOT NULL
              AND expiry_date != ''
              AND julianday(expiry_date) - julianday('now') BETWEEN 0 AND 3
            """
        ).fetchone()[0]
        return render_template(
            "home.html", stock_count=stock_count, expiring_count=expiring_count
        )

    @app.get("/inventory")
    def inventory():
        items = get_db().execute(
            """
            SELECT *,
                   CASE
                     WHEN expiry_date IS NULL OR expiry_date = '' THEN '未設定'
                     WHEN julianday(expiry_date) < julianday('now') THEN '期限切れ'
                     WHEN julianday(expiry_date) - julianday('now') <= 3 THEN '期限間近'
                     ELSE '通常'
                   END AS expiry_status
            FROM inventory_items
            ORDER BY
              CASE WHEN expiry_date IS NULL OR expiry_date = '' THEN 1 ELSE 0 END,
              expiry_date ASC,
              name ASC
            """
        ).fetchall()
        return render_template("inventory.html", items=items)

    @app.post("/inventory/add")
    def add_inventory():
        name = request.form.get("name", "").strip()
        unit = request.form.get("unit", "個").strip() or "個"
        expiry_date = request.form.get("expiry_date", "").strip() or None

        try:
            quantity = float(request.form.get("quantity", "1"))
        except ValueError:
            quantity = 0

        if not name:
            flash("食材名を入力してください。", "error")
            return redirect(url_for("inventory"))
        if quantity < 0:
            flash("数量は0以上で入力してください。", "error")
            return redirect(url_for("inventory"))

        image_filename = save_image(request.files.get("image"), app.config["UPLOAD_FOLDER"])
        db = get_db()
        db.execute(
            """
            INSERT INTO inventory_items (name, quantity, unit, expiry_date, image_filename)
            VALUES (?, ?, ?, ?, ?)
            """,
            (name, quantity, unit, expiry_date, image_filename),
        )
        db.commit()
        flash(f"{name}を在庫に登録しました。", "success")
        return redirect(url_for("inventory"))

    @app.post("/inventory/<int:item_id>/update")
    def update_inventory(item_id):
        db = get_db()
        item = db.execute(
            "SELECT * FROM inventory_items WHERE id = ?", (item_id,)
        ).fetchone()
        if item is None:
            abort(404)

        name = request.form.get("name", "").strip()
        unit = request.form.get("unit", "個").strip() or "個"
        expiry_date = request.form.get("expiry_date", "").strip() or None
        try:
            quantity = float(request.form.get("quantity", "0"))
        except ValueError:
            quantity = -1

        if not name or quantity < 0:
            flash("食材名と数量を正しく入力してください。", "error")
            return redirect(url_for("inventory"))

        image_filename = item["image_filename"]
        if request.files.get("image") and request.files["image"].filename:
            image_filename = save_image(
                request.files["image"], app.config["UPLOAD_FOLDER"]
            )

        db.execute(
            """
            UPDATE inventory_items
            SET name = ?, quantity = ?, unit = ?, expiry_date = ?, image_filename = ?
            WHERE id = ?
            """,
            (name, quantity, unit, expiry_date, image_filename, item_id),
        )
        db.commit()
        flash(f"{name}の在庫を更新しました。", "success")
        return redirect(url_for("inventory"))

    @app.post("/inventory/<int:item_id>/delete")
    def delete_inventory(item_id):
        db = get_db()
        item = db.execute(
            "SELECT name FROM inventory_items WHERE id = ?", (item_id,)
        ).fetchone()
        if item is None:
            abort(404)
        db.execute("DELETE FROM inventory_items WHERE id = ?", (item_id,))
        db.commit()
        flash(f"{item['name']}を削除しました。", "success")
        return redirect(url_for("inventory"))

    @app.route("/recipes", methods=["GET", "POST"])
    def recipes():
        db = get_db()
        items = db.execute(
            "SELECT * FROM inventory_items WHERE quantity > 0 ORDER BY name"
        ).fetchall()
        recipe = None
        selected_ids = []

        if request.method == "POST":
            selected_ids = [int(value) for value in request.form.getlist("item_ids")]
            restrictions = request.form.get("restrictions", "").strip()
            servings = max(1, min(10, request.form.get("servings", 2, type=int)))

            selected_items = [item for item in items if item["id"] in selected_ids]
            if not selected_items:
                flash("使用する在庫食材を1つ以上選んでください。", "error")
            else:
                recipe = generate_recipe(selected_items, restrictions, servings)

        return render_template(
            "recipes.html",
            items=items,
            recipe=recipe,
            selected_ids=selected_ids,
        )

    @app.errorhandler(413)
    def image_too_large(_error):
        flash("画像は5MB以下にしてください。", "error")
        return redirect(url_for("inventory"))

    return app


def save_image(file, upload_folder):
    if not file or not file.filename:
        return None
    filename = secure_filename(file.filename)
    if "." not in filename or filename.rsplit(".", 1)[1].lower() not in ALLOWED_EXTENSIONS:
        abort(400, "画像はPNG、JPEG、WebP形式にしてください。")
    extension = filename.rsplit(".", 1)[1].lower()
    unique_name = f"{secrets.token_hex(8)}.{extension}"
    file.save(Path(upload_folder) / unique_name)
    return unique_name


app = create_app()


if __name__ == "__main__":
    app.run(debug=True)
